-- Correcao: a versao original desta migracao recriava tabelas que a
-- migracao 20231221010804_tables ja tinha criado (CREATE TABLE "users" etc),
-- o que quebra "prisma migrate deploy" em qualquer instalacao nova.
-- Esta versao aplica so o delta real: novas colunas + novas tabelas.

-- AlterTable: novas colunas em "users"
ALTER TABLE "users" ADD COLUMN "app_text_version" INTEGER NOT NULL DEFAULT 1;
ALTER TABLE "users" ADD COLUMN "app_layout_version" INTEGER NOT NULL DEFAULT 1;
ALTER TABLE "users" ADD COLUMN "app_config_version" INTEGER NOT NULL DEFAULT 1;

-- AlterTable: novas colunas em "app_configs" (DNSTT + Hysteria)
ALTER TABLE "app_configs" ADD COLUMN "dnstt_key" TEXT;
ALTER TABLE "app_configs" ADD COLUMN "dnstt_name_server" TEXT;
ALTER TABLE "app_configs" ADD COLUMN "dnstt_server" TEXT;
ALTER TABLE "app_configs" ADD COLUMN "hy_obfs" TEXT;
ALTER TABLE "app_configs" ADD COLUMN "hy_insecure" BOOLEAN;
ALTER TABLE "app_configs" ADD COLUMN "hy_port" TEXT;
ALTER TABLE "app_configs" ADD COLUMN "hy_up_mbps" INTEGER;
ALTER TABLE "app_configs" ADD COLUMN "hy_down_mbps" INTEGER;
ALTER TABLE "app_configs" ADD COLUMN "hy_version" INTEGER;

-- CreateTable: "cdn" (nova, nao existia na migracao anterior)
CREATE TABLE IF NOT EXISTS "cdn" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    CONSTRAINT "cdn_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable: "app_layout_storages" (nova, nao existia na migracao anterior)
CREATE TABLE IF NOT EXISTS "app_layout_storages" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "label" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "value" TEXT,
    "app_layout_id" INTEGER NOT NULL,
    CONSTRAINT "app_layout_storages_app_layout_id_fkey" FOREIGN KEY ("app_layout_id") REFERENCES "app_layouts" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
