#!/usr/bin/env bash
#
# install.sh - Instalação automatizada do painel DTunnel (compatível BASEV25)
#
# Uso:
#   sudo ./install.sh -d painel.seudominio.com -p 3000 -e voce@email.com -s SuaSenhaForte
#
# Parâmetros:
#   -d, --domain     Subdomínio/domínio que vai apontar pro painel (obrigatório)
#   -p, --port       Porta interna do Node.js                       (padrão: 3000)
#   -e, --email      E-mail do admin (usado no login e no certbot)  (obrigatório)
#   -s, --password   Senha do admin                                 (obrigatório)
#   -u, --username   Usuário do admin                                (padrão: derivado do e-mail)
#       --env FILE   Usa um arquivo .env já pronto em vez de gerar um novo
#   -h, --help       Mostra essa ajuda
#
# Requisitos: rodar como root, numa VPS Debian/Ubuntu, com o DNS do domínio
# já apontando pro IP do servidor (necessário pro certbot emitir o certificado).

set -euo pipefail

# ============================================================
#  VALORES PRÉ-CADASTRADOS (padrão caso não passe o parâmetro)
#  Edite aqui se quiser deixar fixo pra você.
# ============================================================
DEFAULT_DOMAIN=""
DEFAULT_PORT="3000"
DEFAULT_EMAIL=""
DEFAULT_PASSWORD=""
DEFAULT_USERNAME=""
# ============================================================

DOMAIN="$DEFAULT_DOMAIN"
PORT="$DEFAULT_PORT"
EMAIL="$DEFAULT_EMAIL"
PASSWORD="$DEFAULT_PASSWORD"
USERNAME="$DEFAULT_USERNAME"
ENV_FILE=""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$SCRIPT_DIR"

log()  { echo -e "\033[1;32m[+]\033[0m $*"; }
warn() { echo -e "\033[1;33m[!]\033[0m $*"; }
err()  { echo -e "\033[1;31m[x]\033[0m $*" >&2; }

usage() {
	grep -E '^#( |$)' "$0" | sed -e 's/^# \{0,1\}//' | sed -n '2,20p'
	exit 1
}

# ---------- parse de argumentos ----------
while [ $# -gt 0 ]; do
	case "$1" in
		-d|--domain)   DOMAIN="$2"; shift 2 ;;
		-p|--port)     PORT="$2"; shift 2 ;;
		-e|--email)    EMAIL="$2"; shift 2 ;;
		-s|--password) PASSWORD="$2"; shift 2 ;;
		-u|--username) USERNAME="$2"; shift 2 ;;
		--env)         ENV_FILE="$2"; shift 2 ;;
		-h|--help)     usage ;;
		*) err "Parâmetro desconhecido: $1"; usage ;;
	esac
done

[ -z "$DOMAIN" ]   && { err "Faltou o subdomínio (-d)."; usage; }
[ -z "$EMAIL" ]    && { err "Faltou o e-mail (-e)."; usage; }
[ -z "$PASSWORD" ] && { err "Faltou a senha (-s)."; usage; }
[ -z "$USERNAME" ] && USERNAME="$(echo "${EMAIL%@*}" | tr -cd 'a-zA-Z0-9' | tr 'A-Z' 'a-z')"
[ ${#USERNAME} -lt 6 ] && USERNAME="${USERNAME}admin"

if [ "$EUID" -ne 0 ]; then
	err "Rode como root (sudo ./install.sh ...)."
	exit 1
fi

log "Domínio: $DOMAIN"
log "Porta interna: $PORT"
log "Admin: $USERNAME <$EMAIL>"
log "Diretório do painel: $APP_DIR"

# ---------- 1. dependências do sistema ----------
log "Atualizando pacotes e instalando dependências..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl git build-essential ca-certificates gnupg nginx certbot python3-certbot-nginx sqlite3

if ! command -v node >/dev/null 2>&1 || [ "$(node -v | cut -d. -f1 | tr -d v)" -lt 20 ]; then
	log "Instalando Node.js 20.x..."
	curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
	apt-get install -y nodejs
else
	log "Node.js já instalado: $(node -v)"
fi

if ! command -v pm2 >/dev/null 2>&1; then
	log "Instalando pm2 globalmente..."
	npm install -g pm2
fi

# ---------- 2. .env ----------
cd "$APP_DIR"

if [ -n "$ENV_FILE" ]; then
	[ ! -f "$ENV_FILE" ] && { err "Arquivo .env informado não existe: $ENV_FILE"; exit 1; }
	log "Usando .env fornecido: $ENV_FILE"
	cp "$ENV_FILE" "$APP_DIR/.env"
	# garante que a porta do parâmetro prevaleça
	if grep -q '^PORT=' "$APP_DIR/.env"; then
		sed -i "s/^PORT=.*/PORT=$PORT/" "$APP_DIR/.env"
	else
		echo "PORT=$PORT" >> "$APP_DIR/.env"
	fi
elif [ -f "$APP_DIR/.env" ]; then
	log ".env já existe no projeto, mantendo como está (ajustando só a porta)."
	if grep -q '^PORT=' "$APP_DIR/.env"; then
		sed -i "s/^PORT=.*/PORT=$PORT/" "$APP_DIR/.env"
	else
		echo "PORT=$PORT" >> "$APP_DIR/.env"
	fi
else
	log "Gerando novo .env com segredos aleatórios..."
	CSRF_SECRET="$(openssl rand -hex 32)"
	JWT_SECRET_KEY="$(openssl rand -hex 32)"
	JWT_SECRET_REFRESH="$(openssl rand -hex 32)"
	cat > "$APP_DIR/.env" <<EOF
PORT=$PORT
NODE_ENV="production"
DATABASE_URL="file:./database.db"
CSRF_SECRET="$CSRF_SECRET"
JWT_SECRET_KEY="$JWT_SECRET_KEY"
JWT_SECRET_REFRESH="$JWT_SECRET_REFRESH"
EOF
fi

chmod 600 "$APP_DIR/.env"

# ---------- 3. instalação e build do projeto ----------
log "Instalando dependências do Node (npm install)..."
npm install

log "Gerando client do Prisma..."
npx prisma generate

log "Rodando migrações do banco..."
npx prisma migrate deploy

log "Compilando TypeScript (npm run build)..."
npm run build

# ---------- 4. usuário admin pré-cadastrado ----------
log "Criando/atualizando usuário admin no banco..."
cat > "$APP_DIR/.seed-admin.cjs" <<'EOF'
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');

const [,, username, email, password] = process.argv;
const prisma = new PrismaClient();

(async () => {
	const passwordHash = bcrypt.hashSync(password, 10);

	const existing = await prisma.user.findFirst({ where: { email } });

	const user = existing
		? await prisma.user.update({
				where: { id: existing.id },
				data: { username, password: passwordHash },
		  })
		: await prisma.user.create({
				data: { username, email, password: passwordHash },
		  });

	console.log('ADMIN_USER_ID=' + user.id);
	await prisma.$disconnect();
})().catch(async (e) => {
	console.error(e);
	await prisma.$disconnect();
	process.exit(1);
});
EOF

ADMIN_LINE="$(node "$APP_DIR/.seed-admin.cjs" "$USERNAME" "$EMAIL" "$PASSWORD" | tail -n1)"
ADMIN_USER_ID="${ADMIN_LINE#ADMIN_USER_ID=}"
rm -f "$APP_DIR/.seed-admin.cjs"

if [ -z "$ADMIN_USER_ID" ]; then
	err "Não foi possível criar o usuário admin. Veja o log acima."
	exit 1
fi

log "Admin criado. user_id (use como dragoncore-token no app): $ADMIN_USER_ID"

# ---------- 5. nginx (proxy reverso) ----------
log "Configurando nginx para $DOMAIN -> 127.0.0.1:$PORT ..."
NGINX_CONF="/etc/nginx/sites-available/$DOMAIN"
cat > "$NGINX_CONF" <<EOF
server {
	listen 80;
	server_name $DOMAIN;

	location / {
		proxy_pass http://127.0.0.1:$PORT;
		proxy_http_version 1.1;
		proxy_set_header Upgrade \$http_upgrade;
		proxy_set_header Connection 'upgrade';
		proxy_set_header Host \$host;
		proxy_set_header X-Real-IP \$remote_addr;
		proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
		proxy_set_header X-Forwarded-Proto \$scheme;
		proxy_cache_bypass \$http_upgrade;
	}
}
EOF

ln -sf "$NGINX_CONF" "/etc/nginx/sites-enabled/$DOMAIN"
nginx -t
systemctl reload nginx

# ---------- 6. certbot (HTTPS) ----------
log "Emitindo certificado SSL com certbot..."
certbot --nginx -d "$DOMAIN" -m "$EMAIL" --agree-tos --redirect --non-interactive || {
	warn "Certbot falhou. Confirme se o DNS de $DOMAIN já aponta pro IP deste servidor e rode manualmente:"
	warn "  certbot --nginx -d $DOMAIN -m $EMAIL --agree-tos --redirect"
}

# ---------- 7. subir com pm2 ----------
log "Iniciando o painel com pm2..."
pm2 delete DTunnel >/dev/null 2>&1 || true
pm2 start "$APP_DIR/ecosystem.config.js"
pm2 save
pm2 startup systemd -u root --hp /root >/dev/null 2>&1 || true

# ---------- resumo ----------
SUMMARY_FILE="$APP_DIR/INSTALL_INFO.txt"
cat > "$SUMMARY_FILE" <<EOF
== Painel instalado ==
URL:            https://$DOMAIN
Porta interna:  $PORT
.env:           $APP_DIR/.env

== Admin (login no painel) ==
Usuário:  $USERNAME
E-mail:   $EMAIL
Senha:    (a que você informou no parâmetro -s)

== Para configurar no app (BASEV25 / Dragoncore) ==
dragoncore-token = $ADMIN_USER_ID
Endpoint         = https://$DOMAIN/api2
EOF
chmod 600 "$SUMMARY_FILE"

log "Instalação concluída!"
log "Resumo salvo em: $SUMMARY_FILE"
cat "$SUMMARY_FILE"
