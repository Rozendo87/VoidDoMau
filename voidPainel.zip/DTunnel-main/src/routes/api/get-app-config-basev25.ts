import prisma from '../../config/prisma-client';
import SafeCallback from '../../utils/safe-callback';
import { AppConfigSelect } from '../../routes/DTunnel/AppConfig/zod-schema';
import { AppConfigParser } from '../../utils/parsers/app-config-parser';

// Igual a src/routes/api/get-app-config.ts, MAS usando AppConfigParser
// (que preserva o campo "category") em vez de AppConfigParserApi (que apaga
// o campo "category" da resposta).
//
// O app BASEV25 le category.name / category.sorter direto de cada servidor
// pra montar o dropdown de categorias (ver SocksReviveMainActivity.java,
// metodo de parse da lista de servidores). Sem esse campo, todo servidor cai
// na categoria "Unknown".
//
// Nao alteramos get-app-config.ts original pra nao afetar o app/painel
// DTunnel padrao, que usa AppConfigParserApi de proposito.

const BASEV25_SUPPORTED_MODES = [
  'SSH_DIRECT',
  'SSH_PROXY',
  'SSH_DNSTT',
  'SSL_DIRECT',
  'SSL_PROXY',
  'V2RAY',
];

export default async function GetAppConfigBaseV25(user_id: string) {
  const AppConfig = await SafeCallback(() =>
    prisma.appConfig.findMany({
      where: {
        user_id,
        status: 'ACTIVE',
        mode: { in: BASEV25_SUPPORTED_MODES },
        category: {
          status: 'ACTIVE',
        },
      },
      select: {
        ...AppConfigSelect,
      },
    })
  );
  if (!AppConfig?.length) return [];
  return AppConfig.map(AppConfigParser);
}
