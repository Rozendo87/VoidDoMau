import { z } from 'zod';
import GetAppText from './get-app-text';
import AESCrypt from '../../utils/crypto';
import GetAppConfigBaseV25 from './get-app-config-basev25';
import GetAppLayout from './get-app-layout';
import { FastifyReply, FastifyRequest, RouteOptions } from 'fastify';

// Rota compativel com o app BASEV25 (fork "Dragoncore" do DTunnel).
// O app faz: POST https://SEU_DOMINIO/api2
// com os headers abaixo e body vazio, e espera receber:
//   { "data": "<base64 AES-256-CBC>" }

const headerSchema = z.object({
  password: z.string().optional(),
  'dragoncore-token': z.string(),
  'dragoncore-update': z.enum(['app_config', 'app_layout', 'app_text']),
  'user-agent': z.literal('Dragoncore (@penguinehis, @sisudragon)'),
});

const handler = {
  app_text: GetAppText,
  app_config: GetAppConfigBaseV25,
  app_layout: GetAppLayout,
};

// Mesma senha usada em SocksReviveMainActivity.java -> decryptAES(encryptedData, "...")
const AES_PASSWORD = '05VE1b3kx10ntsfzvsSmZD3KYuilFXyS';

export default {
  url: '/api2',
  method: 'POST',
  handler: async (req: FastifyRequest, reply: FastifyReply) => {
    const headers = headerSchema.safeParse(req.headers);
    if (!headers.success) return reply.send();

    const user_id = headers.data['dragoncore-token'];
    const response = await handler[headers.data['dragoncore-update']](user_id);

    // Modo debug: se mandar o header "password" com a senha certa, devolve sem criptografar
    if (headers.data.password === AES_PASSWORD) {
      if (['app_config', 'app_layout'].includes(headers.data['dragoncore-update'])) {
        return reply.send(response.map((data: any) => JSON.parse(data)));
      }
      return reply.send(response);
    }

    // Caminho normal: exatamente o que decryptAES() do app espera -> {"data": "<b64>"}
    reply.send({ data: AESCrypt.encrypt(AES_PASSWORD, JSON.stringify(response)) });
  },
} as RouteOptions;
